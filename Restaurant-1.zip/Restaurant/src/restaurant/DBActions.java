package restaurant;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;

public class DBActions {

	public static void addCustomer(String name, String address, long phone, String email) {
		Connection sqlConnection = null;
		PreparedStatement pstmt = null;
		if (name != null && address != null) {
			if (name != null) {
				try {
					sqlConnection = DBUtility.getConnection();
					sqlConnection.setAutoCommit(false);
					pstmt = sqlConnection.prepareStatement(
							"insert into customer (customer_name,address, phone_num, email_add) values (?, ?, ?, ?)");
					pstmt.setString(1, name);
					pstmt.setString(2, address);
					pstmt.setLong(3, phone);
					pstmt.setString(4, email);
					pstmt.execute();
					sqlConnection.commit();
				}

				catch (Exception e) {
					System.err.println("Error in addCustomer method .... " + e);
					e.printStackTrace();
				} finally

				{
					// DbUtils.closeQuietly(psLmt) ;
					// DbUtils.closeQuietly(sqlConnection) ;
				}
			}
		}
	}

	public static void addProduct(String product, double price) {
		Connection sqlConnection = null;
		PreparedStatement pstmt = null;
		if (product != null && price > 0) {
			try {
				sqlConnection = DBUtility.getConnection();
				sqlConnection.setAutoCommit(false);
				pstmt = sqlConnection
						.prepareStatement("insert into product (product_name,product_price) values (?, ?)");
				pstmt.setString(1, product);
				pstmt.setDouble(2, price);
				pstmt.execute();

				sqlConnection.commit();
			} catch (Exception e) {
				System.err.println("Error in addProduct method .... " + e);
			} finally {
				// jjDbUtils.closeQuietly(psLmL) ;
				// jjDbUtils.closeQuietly(sqlConnection) ;
			}
		}
	}

	public static ArrayList<String> getCustomerList() {
		Connection sqlConnection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<String> custList = new ArrayList<String>();
		try {
			sqlConnection = DBUtility.getConnection();
			sqlConnection.setAutoCommit(false);

			pstmt = sqlConnection.prepareStatement(
					"select customer_id, customer_name,address, phone_num, email_add from customer order by customer_name");
			rs = pstmt.executeQuery();
			while (rs.next()) {
				int id = rs.getInt("customer_id");
				String name = rs.getString("customer_name");
				String address = rs.getString("address");
				String phone = rs.getString("phone_num");

				String email = rs.getString("email_add");

				if (address == null)
					address = "";
				if (phone == null)
					phone = "";
				String record = name + Billing.delimiter + String.valueOf(id) + Billing.delimiter + address
						+ Billing.delimiter + phone + Billing.delimiter + email;
				custList.add(record);
			}
		} catch (Exception e) {
			System.err.println("Error in getCustomerList method .... " + e);
		} finally {
			// DbUtils.closeQuietly(psLmL) ;
			// DbUtils.closeQuietly(sqlConnection) ;
		}
		return custList;
	}

	public static ArrayList<String> getProductList() {
		Connection sqlConnection = null;

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<String> prodList = new ArrayList<String>();
		try {
			sqlConnection = DBUtility.getConnection();
			sqlConnection.setAutoCommit(false);

			pstmt = sqlConnection.prepareStatement(
					"select product_id, product_name,product_price from product order by product_name");
			rs = pstmt.executeQuery();
			while (rs.next()) {
				int id = rs.getInt("product_id");
				String name = rs.getString("product_name");
				BigDecimal price = rs.getBigDecimal("product_price");
				String record = name + Billing.delimiter + String.valueOf(id) + Billing.delimiter
						+ String.valueOf(price);
				prodList.add(record);
			}
		} catch (

		Exception e) {
			System.err.println("Error in getProductList method .... " + e);
		} finally {
			// DbUtils.closeQuietly(psLmt) ;
			// DbUtils.closeQuietly(sqlConnection) ;
		}
		return prodList;
	}

	public static int addNewOrder(String custId, String totalCost) {
		Connection sqlConnection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int orderId = 0;
		if (custId != null && totalCost != null) {
			try {
				sqlConnection = DBUtility.getConnection();
				sqlConnection.setAutoCommit(false);
				pstmt = sqlConnection.prepareStatement(
						"insert into orders (customer_id, order_date, total_cost) values (?, ?, ?) ",
						new String[] { "order_id" });
				pstmt.setInt(1, Integer.parseInt(custId));
				pstmt.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
				pstmt.setBigDecimal(3, new BigDecimal(totalCost));
				if (pstmt.executeUpdate() > 0) {
					rs = pstmt.getGeneratedKeys();
					while (rs.next()) {
						orderId = rs.getInt(1);
					}

				}
				sqlConnection.commit();
			} catch (Exception e) {
				System.err.println("Error in addNewOrder method .... " + e);
			} finally {
				// DbUtils.closeQuietly(pstmL);
				// DbUtils.closeQuietly(sqlConnection);
			}
		}
		return orderId;

	}

	public static void addOrderDetails(int orderId, int prodId, int qty) {
		Connection sqlConnection = null;
		PreparedStatement pstmt = null;
		if (orderId > 0 && prodId > 0 && qty > 0) {
			try {
				sqlConnection = DBUtility.getConnection();
				sqlConnection.setAutoCommit(false);
				pstmt = sqlConnection.prepareStatement(
						"insert into order_detail (order_id, product_id, quantity) values (?, ?, ?) ");
				pstmt.setInt(1, orderId);
				pstmt.setInt(2, prodId);
				pstmt.setInt(3, qty);
				pstmt.executeUpdate();
				sqlConnection.commit();
			} catch (Exception e) {
				e.printStackTrace();
				System.err.println("Error in addOrderDetails method .... " + e);
			} finally {
				// DbUtils.closeQuietly(pstmL);
				// DbUtils.closeQuietly(sqlConnection);
			}
		}
	}
	/*
	 * public static void main(String args[]) String name = "Ranga"; String
	 * address = "Mississauga, Canada"; String product = "Rice"; double price =
	 * 5.50; //ArrayList custList = getCustomerList(); //ArrayList prodList =
	 * getProductList(); // i.n.t. orderId = addNewOrder ( "2", "10");
	 * addOrderDetails(2, I, 1); //System.out.prjntln("orderId:" + orderId); //
	 * addCustomer(name, address); //addProduct(product, price) i
	 * 
	 * 
	 * 
	 * }
	 */
}
