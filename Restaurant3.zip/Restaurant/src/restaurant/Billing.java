
package restaurant;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;

public class Billing {
	public static final String delimiter = " : ";

	private JFrame mainFrame;
	private JFrame addCustFrame;
	private JFrame addProdFrame;
	private JFrame newOrderFrame;

	private JLabel statusMainLabel;
	private JLabel statusCustLabel;
	private JLabel statusProdLabel;
	private JLabel statusOrderLabel;

	private JTextField tfCustName;
	private JTextField tfAddress;
	private JTextField tfPhone;
	private JTextField tfEmail;
	private JTextField tfProdName;
	private JTextField tfPrice;
	private JPanel orderSummaryPanel;
	private JPanel custInfoPanel;
	private JPanel orderInfoPanel;

	private GridBagConstraints cSOrderFrame;
	private GridBagConstraints csCustInfo;
	private GridBagConstraints csOrderInfo;
	private GridBagConstraints csAddCustomer;

	private GridBagConstraints csAddProduct;
	private GridBagConstraints csOrderSummary;
	private int orderSummaryY = 0;
	private int orderInfoY = 0;
	private int custInfoY = 0;
	private JTextField tfOrderID;
	private JTextField tfOrderDate;
	private JTextField tfOrderCustName;
	private JTextField tfOrderCustAddress;
	private JTextField tfOrderCustPhone;
	private JTextField tfOrderCustEmail;
	private JComboBox<String> cbOrderCustNameList;
	private JTextField tfOrderTotal;
	private int itemNumber = 0;
	private int maxItemCount = 20;
	private JTextField tfOrderProdName[] = new JTextField[maxItemCount];
	private JTextField tfOrderUnitPrice[] = new JTextField[maxItemCount];
	private JTextField tfOrderQantity[] = new JTextField[maxItemCount];
	private JTextField tfOrderSubTotal[] = new JTextField[maxItemCount];
	private JComboBox<String> cbProdNameList[] = new JComboBox[maxItemCount];
	private String[] customerList;
	private String[] productList;
	// private JPanel custInfoPanel;

	private String orderCustomerld;
	private String[] orderProductld = new String[maxItemCount];

	Billing() {

	}

	// new String[maxItemCount];

	public static void main(String[] args) {
		new Billing().showBillingGUI();
	}

	private void showBillingGUI() {
		mainFrame = new JFrame("RAJAT Restaurant - Billing System");
		mainFrame.setSize(600, 400);
		mainFrame.setLayout(new GridLayout(5, 1));
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JLabel headerMainLabel = new JLabel("Welcome to RAJAT Restaurant!", JLabel.CENTER);
		statusMainLabel = new JLabel("", JLabel.CENTER);
		JPanel addCustPanel = new JPanel();
		addCustPanel.setLayout(new FlowLayout());
		JPanel addProdPanel = new JPanel();
		addProdPanel.setLayout(new FlowLayout());
		JPanel newOrderPanel = new JPanel();
		newOrderPanel.setLayout(new FlowLayout());
		mainFrame.add(headerMainLabel);
		mainFrame.add(addCustPanel);
		mainFrame.add(addProdPanel);
		mainFrame.add(newOrderPanel);
		mainFrame.add(statusMainLabel);
		mainFrame.setVisible(true);

		JButton addCustButton = new JButton("Add Customer");

		JButton addProdButton = new JButton("Add Product");
		JButton newOrderButton = new JButton("New Order");
		addCustButton.addActionListener(new AddCustomerClickListener());
		addProdButton.addActionListener(new AddProductClickListener());
		newOrderButton.addActionListener(new NewOrderClickListener());
		addCustPanel.add(addCustButton);
		addProdPanel.add(addProdButton);
		newOrderPanel.add(newOrderButton);
		mainFrame.setVisible(true);
	}

	private class AddCustomerClickListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			statusMainLabel.setText("Last Action: Add Customer Button clicked !");
			addCustFrame = new JFrame("Add Customer Screenl");
			addCustFrame.setSize(600, 400);
			addCustFrame.setLayout(new GridLayout(4, 2));
			addCustFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			JLabel headerCustLabel = new JLabel("Add New Customer", JLabel.CENTER);
			statusCustLabel = new JLabel(" ", JLabel.CENTER);
			JPanel textPanel = new JPanel(new GridBagLayout());
			csAddCustomer = new GridBagConstraints();
			csAddCustomer.fill = GridBagConstraints.HORIZONTAL;
			JLabel lbUserName = new JLabel("Customer Name: ");
			setAddCustomerGrid(0, 1, 1);
			textPanel.add(lbUserName, csAddCustomer);
			tfCustName = new JTextField(20);
			setAddCustomerGrid(1, 1, 1);
			textPanel.add(tfCustName, csAddCustomer);
			JLabel lbCustAddress = new JLabel("Address: ");
			setAddCustomerGrid(0, 2, 1);
			textPanel.add(lbCustAddress, csAddCustomer);
			tfAddress = new JTextField(40);
			setAddCustomerGrid(1, 2, 2);
			textPanel.add(tfAddress, csAddCustomer);
			JLabel lbCustPhone = new JLabel("Phone Number: ");
			setAddCustomerGrid(0, 3, 1);
			textPanel.add(lbCustPhone, csAddCustomer);
			tfPhone = new JTextField(20);
			setAddCustomerGrid(1, 3, 1);
			textPanel.add(tfPhone, csAddCustomer);
			JLabel lbCustEmail = new JLabel("Email ID: ");
			setAddCustomerGrid(0, 4, 1);
			textPanel.add(lbCustEmail, csAddCustomer);
			tfEmail = new JTextField(20);
			setAddCustomerGrid(1, 4, 1);
			textPanel.add(tfEmail, csAddCustomer);
			textPanel.setBorder(new LineBorder(Color.GRAY));
			JPanel buttonPanel = new JPanel();
			JButton cancelButton = new JButton("Cancel");
			cancelButton.setActionCommand("AddCustomerCancel");
			cancelButton.addActionListener(new CancelClickListener());
			JButton submitButton = new JButton("Submit");
			submitButton.setActionCommand("AddCustomerSubmit");
			submitButton.addActionListener(new SubmitClickListener());
			JButton resetButton = new JButton("Reset");
			resetButton.setActionCommand("AddCustomerReset");
			resetButton.addActionListener(new ResetClickListener());
			buttonPanel.add(submitButton);
			buttonPanel.add(Box.createRigidArea(new Dimension(10, 0)));
			buttonPanel.add(resetButton);
			buttonPanel.add(Box.createRigidArea(new Dimension(10, 0)));
			buttonPanel.add(cancelButton);
			addCustFrame.add(headerCustLabel);
			addCustFrame.add(textPanel);
			addCustFrame.add(buttonPanel);
			addCustFrame.add(statusCustLabel);
			addCustFrame.setVisible(true);
		}
	}

	private class AddProductClickListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			statusMainLabel.setText("Last Action: Add Product Button clicked !");
			addProdFrame = new JFrame("Add Product Screen");
			addProdFrame.setSize(600, 300);
			addProdFrame.setLayout(new GridLayout(4, 2));
			addProdFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			JLabel headerProdLabel = new JLabel("Add New Product", JLabel.CENTER);
			statusProdLabel = new JLabel(" ", JLabel.CENTER);
			JPanel textPanel = new JPanel(new GridBagLayout());
			csAddProduct = new GridBagConstraints();
			csAddProduct.fill = GridBagConstraints.HORIZONTAL;
			JLabel lbProdName = new JLabel("product Name: ");
			setAddProductGrid(0, 1, 1);
			textPanel.add(lbProdName, csAddProduct);
			tfProdName = new JTextField(40);
			setAddProductGrid(1, 1, 2);
			textPanel.add(tfProdName, csAddProduct);
			JLabel lbPrice = new JLabel("Price: ");
			setAddProductGrid(0, 2, 1);
			textPanel.add(lbPrice, csAddProduct);
			tfPrice = new JTextField(10);
			setAddProductGrid(1, 2, 1);
			textPanel.add(tfPrice, csAddProduct);
			textPanel.setBorder(new LineBorder(Color.GRAY));
			JPanel buttonPanel = new JPanel();
			JButton cancelButton = new JButton("Cancel");
			cancelButton.setActionCommand("AddProductCancel");
			cancelButton.addActionListener(new CancelClickListener());
			JButton submitButton = new JButton("Submit");
			submitButton.setActionCommand("AddProductSubmit");
			submitButton.addActionListener(new SubmitClickListener());
			JButton resetButton = new JButton("Reset");
			resetButton.setActionCommand("AddProductReset");
			resetButton.addActionListener(new ResetClickListener());
			buttonPanel.add(submitButton);
			buttonPanel.add(Box.createRigidArea(new Dimension(10, 0)));
			buttonPanel.add(resetButton);
			buttonPanel.add(Box.createRigidArea(new Dimension(10, 0)));
			buttonPanel.add(cancelButton);
			addProdFrame.add(headerProdLabel);
			addProdFrame.add(textPanel);
			addProdFrame.add(buttonPanel);
			addProdFrame.add(statusProdLabel);
			addProdFrame.setVisible(true);
		}
	}

	private class NewOrderClickListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			statusMainLabel.setText("Last Action: New Order Button clicked !");
			newOrderFrame = new JFrame("New Order Screen");
			newOrderFrame.setSize(800, 700); // 800*600 or 1024*768 or
			// setSize(getMaximumSize());
			newOrderFrame.setLayout(new GridBagLayout());
			cSOrderFrame = new GridBagConstraints();
			cSOrderFrame.fill = GridBagConstraints.HORIZONTAL;
			newOrderFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			JLabel headerOrderLabel = new JLabel("Place New Order", JLabel.CENTER);

			statusOrderLabel = new JLabel(" ", JLabel.CENTER);

			// to populate the drop downs
			 populateProdCustList();//SUNIL
			// orderSummaryPanel
			setOrderSummaryPanel();
			// custlnfoPanel
			setCustInfoPanel();
			// orderInfoPanel
			setOrderInfoPanel();

			// II calculatePanel
			JPanel calculatePanel = new JPanel();
			JButton calculateButton = new JButton("Calculate");
			calculateButton.setActionCommand("NewOrderCalculate");
			calculateButton.addActionListener(new SubmitClickListener());
			JButton addItemButton = new JButton("Add Item");
			addItemButton.setActionCommand("NewOrderAddItem");
			addItemButton.addActionListener(new SubmitClickListener());
			JLabel lbOrderTotal = new JLabel("Total: ");
			custInfoPanel.add(lbOrderTotal);
			tfOrderTotal = new JTextField(10);
			tfOrderTotal.setEditable(false);
			custInfoPanel.add(tfOrderTotal);
			calculatePanel.add(addItemButton);
			calculatePanel.add(Box.createRigidArea(new Dimension(10, 0)));
			calculatePanel.add(calculateButton);
			calculatePanel.add(Box.createRigidArea(new Dimension(10, 0)));
			calculatePanel.add(lbOrderTotal);
			calculatePanel.add(tfOrderTotal);
			// II buttonPanel
			JPanel buttonPanel = new JPanel();
			JButton cancelButton = new JButton("Cancel");
			cancelButton.setActionCommand("NewOrderCancel");
			cancelButton.addActionListener(new CancelClickListener());
			JButton submitButton = new JButton("Submit");
			submitButton.setActionCommand("NewOrderSubmit");
			submitButton.addActionListener(new SubmitClickListener());
			JButton resetButton = new JButton("Reset");
			resetButton.setActionCommand("NewOrderReset");
			resetButton.addActionListener(new ResetClickListener());
			buttonPanel.add(submitButton);
			buttonPanel.add(Box.createRigidArea(new Dimension(10, 0)));
			buttonPanel.add(resetButton);
			buttonPanel.add(Box.createRigidArea(new Dimension(10, 0)));
			buttonPanel.add(cancelButton);
			int orderFrameY = 0;
			setOrderFrameGrid(1, orderFrameY++, 1);
			newOrderFrame.add(headerOrderLabel, cSOrderFrame);
			setOrderFrameGrid(0, orderFrameY++, 1);
			newOrderFrame.add(new JLabel(" "), cSOrderFrame);

			// 1:\work_helper\Rajat\ReSlaurant\src\reslaurant\Billing.java
			setOrderFrameGrid(0, orderFrameY++, 3);
			newOrderFrame.add(orderSummaryPanel, cSOrderFrame);
			setOrderFrameGrid(0, orderFrameY++, 1);
			newOrderFrame.add(new JLabel(" "), cSOrderFrame);
			setOrderFrameGrid(0, orderFrameY++, 3);
			newOrderFrame.add(custInfoPanel, cSOrderFrame);
			setOrderFrameGrid(0, orderFrameY++, 1);
			newOrderFrame.add(new JLabel(" "), cSOrderFrame);
			setOrderFrameGrid(0, orderFrameY++, 4);
			newOrderFrame.add(orderInfoPanel, cSOrderFrame);
			setOrderFrameGrid(0, orderFrameY++, 1);
			newOrderFrame.add(new JLabel(" "), cSOrderFrame);
			setOrderFrameGrid(0, orderFrameY++, 2);
			newOrderFrame.add(calculatePanel, cSOrderFrame);
			setOrderFrameGrid(0, orderFrameY++, 1);
			newOrderFrame.add(new JLabel(" "), cSOrderFrame);
			setOrderFrameGrid(0, orderFrameY++, 2);
			newOrderFrame.add(buttonPanel, cSOrderFrame);
			setOrderFrameGrid(0, orderFrameY++, 1);
			newOrderFrame.add(new JLabel(" "), cSOrderFrame);
			setOrderFrameGrid(1, orderFrameY++, 1);
			newOrderFrame.add(statusOrderLabel, cSOrderFrame);
			newOrderFrame.setVisible(true);
		}
	}

	private void setOrderSummaryPanel() {
		orderSummaryPanel = new JPanel(new GridBagLayout());
		csOrderSummary = new GridBagConstraints();
		csOrderSummary.fill = GridBagConstraints.HORIZONTAL;
		JLabel orderSummaryLabel = new JLabel("Order Summary");
		setOrderSummaryGrid(2, orderSummaryY, 1);
		orderSummaryPanel.add(orderSummaryLabel, csOrderSummary);
		orderSummaryY++;
		setOrderSummaryGrid(2, orderSummaryY, 1);
		orderSummaryPanel.add(new JLabel(" "), csOrderSummary);
		orderSummaryY++;
		JLabel lbOrderID = new JLabel("Order ID: ");
		setOrderSummaryGrid(0, orderSummaryY, 1);
		orderSummaryPanel.add(lbOrderID, csOrderSummary);
		tfOrderID = new JTextField(10);
		tfOrderID.setEditable(false);
		setOrderSummaryGrid(1, orderSummaryY, 2);
		orderSummaryPanel.add(tfOrderID, csOrderSummary);
		orderSummaryY++;
		JLabel lbOrderDate = new JLabel("Order Date; ");
		setOrderSummaryGrid(0, orderSummaryY, 1);
		orderSummaryPanel.add(lbOrderDate, csOrderSummary);
		tfOrderDate = new JTextField(40);
		tfOrderDate.setEditable(false);
		setTfOrderDate(getCurrentTime());
		setOrderSummaryGrid(1, orderSummaryY, 2);
		orderSummaryPanel.add(tfOrderDate, csOrderSummary);
		orderSummaryY++;
		setOrderSummaryGrid(2, orderSummaryY, 1);
		orderSummaryPanel.add(new JLabel(" "), csOrderSummary);
		orderSummaryPanel.setBorder(new LineBorder(Color.GRAY));
	}

	private void setCustInfoPanel() {
		custInfoPanel = new JPanel(new GridBagLayout());
		csCustInfo = new GridBagConstraints();
		csCustInfo.fill = GridBagConstraints.HORIZONTAL;
		JLabel cutInfoLabel = new JLabel("Customer Info");
		setCustInfoGrid(2, custInfoY, 1);
		custInfoPanel.add(cutInfoLabel, csCustInfo);
		custInfoY++;
		setCustInfoGrid(2, custInfoY, 1);
		custInfoPanel.add(new JLabel(" 1"), csCustInfo);
		custInfoY++;
		JLabel lbCustList = new JLabel("Choose Customer: ");
		setCustInfoGrid(0, custInfoY, 1);
		custInfoPanel.add(lbCustList, csCustInfo);
		cbOrderCustNameList = new JComboBox<String>(customerList);
		cbOrderCustNameList.setActionCommand("CustNameList");
		cbOrderCustNameList.addActionListener(new ComboSelectListener());
		cbOrderCustNameList.setSelectedIndex(-1);
		setCustInfoGrid(1, custInfoY, 2);
		custInfoPanel.add(cbOrderCustNameList, csCustInfo);
		custInfoY++;
		JLabel lbOrderCustName = new JLabel("Customer Name: ");
		setCustInfoGrid(0, custInfoY, 1);
		custInfoPanel.add(lbOrderCustName, csCustInfo);
		tfOrderCustName = new JTextField(10);
		tfOrderCustName.setEditable(false);
		setCustInfoGrid(1, custInfoY, 2);

		custInfoPanel.add(tfOrderCustName, csCustInfo);
		custInfoY++;
		JLabel lbOrderCustAddress = new JLabel("Address: ");
		setCustInfoGrid(0, custInfoY, 1);
		custInfoPanel.add(lbOrderCustAddress, csCustInfo);
		tfOrderCustAddress = new JTextField(40);
		tfOrderCustAddress.setEditable(false);
		setCustInfoGrid(1, custInfoY, 2);
		custInfoPanel.add(tfOrderCustAddress, csCustInfo);
		custInfoY++;
		JLabel lbOrderCustPhone = new JLabel("Phone Number: ");
		setCustInfoGrid(0, custInfoY, 1);
		custInfoPanel.add(lbOrderCustPhone, csCustInfo);
		tfOrderCustPhone = new JTextField(40);
		tfOrderCustPhone.setEditable(false);
		setCustInfoGrid(1, custInfoY, 2);
		custInfoPanel.add(tfOrderCustPhone, csCustInfo);
		custInfoY++;
		JLabel lbOrderCustEmail = new JLabel("Email ID: ");
		setCustInfoGrid(0, custInfoY, 1);
		custInfoPanel.add(lbOrderCustEmail, csCustInfo);
		tfOrderCustEmail = new JTextField(40);
		tfOrderCustEmail.setEditable(false);
		setCustInfoGrid(1, custInfoY, 2);
		custInfoPanel.add(tfOrderCustEmail, csCustInfo);
		custInfoY++;
		setCustInfoGrid(2, custInfoY, 1);
		custInfoPanel.add(new JLabel(" "), csCustInfo);
		custInfoPanel.setBorder(new LineBorder(Color.GRAY));
	}

	private void setOrderInfoPanel() {
		orderInfoPanel = new JPanel(new GridBagLayout());
		csOrderInfo = new GridBagConstraints();
		csOrderInfo.fill = GridBagConstraints.HORIZONTAL;
		JLabel orderInfoLabel = new JLabel("Order Info");
		setOrderInfoGrid(2, orderInfoY, 1);
		orderInfoPanel.add(orderInfoLabel, csOrderInfo);
		orderInfoY++;
		setOrderInfoGrid(2, orderInfoY, 1);
		orderInfoPanel.add(new JLabel(" "), csOrderInfo);

		orderInfoY++;
		JLabel lbProdList = new JLabel("Choose Product");
		setOrderInfoGrid(0, orderInfoY, 1);
		orderInfoPanel.add(lbProdList, csOrderInfo);
		setOrderInfoGrid(1, orderInfoY, 1);
		orderInfoPanel.add(Box.createRigidArea(new Dimension(30, 0)), csOrderInfo);
		JLabel lbProdQty = new JLabel("Quantity");
		setOrderInfoGrid(2, orderInfoY, 1);
		orderInfoPanel.add(lbProdQty, csOrderInfo);
		setOrderInfoGrid(3, orderInfoY, 1);
		orderInfoPanel.add(Box.createRigidArea(new Dimension(30, 0)), csOrderInfo);
		JLabel lbOrderProdName = new JLabel("Name");
		setOrderInfoGrid(4, orderInfoY, 1);
		orderInfoPanel.add(lbOrderProdName, csOrderInfo);
		setOrderInfoGrid(5, orderInfoY, 1);
		orderInfoPanel.add(Box.createRigidArea(new Dimension(30, 0)), csOrderInfo);
		JLabel lbUnitPrice = new JLabel("Unit Price");
		setOrderInfoGrid(6, orderInfoY, 1);
		orderInfoPanel.add(lbUnitPrice, csOrderInfo);
		setOrderInfoGrid(7, orderInfoY, 1);
		orderInfoPanel.add(Box.createRigidArea(new Dimension(30, 0)), csOrderInfo);
		JLabel lbSubTotal = new JLabel("Sub Total");
		setOrderInfoGrid(8, orderInfoY, 1);
		orderInfoPanel.add(lbSubTotal, csOrderInfo);

		// Add minimum 1 Item by default; More items added on 'Add Item' click;
		addNewOrderItem();
		orderInfoPanel.setBorder(new LineBorder(Color.GRAY));
	}

	private void addNewOrderItem() {
		// System.out.println("addNewOrderItem called:" + itemNumber);
		orderInfoY++;
		cbProdNameList[itemNumber] = new JComboBox<String>(productList);
		cbProdNameList[itemNumber].setActionCommand("ProdNameList");
		// cbProdNameList[itemNumberl .addActionListener(new
		// ComboSelectListener( i
		cbProdNameList[itemNumber].setSelectedIndex(-1);
		setOrderInfoGrid(0, orderInfoY, 1);
		orderInfoPanel.add(cbProdNameList[itemNumber], csOrderInfo);
		setOrderInfoGrid(1, orderInfoY, 1);
		orderInfoPanel.add(Box.createRigidArea(new Dimension(30, 0)), csOrderInfo);
		tfOrderQantity[itemNumber] = new JTextField(5);
		setOrderInfoGrid(2, orderInfoY, 1);
		orderInfoPanel.add(tfOrderQantity[itemNumber], csOrderInfo);
		setOrderInfoGrid(3, orderInfoY, 1);
		orderInfoPanel.add(Box.createRigidArea(new Dimension(30, 0)), csOrderInfo);
		tfOrderProdName[itemNumber] = new JTextField(20);
		tfOrderProdName[itemNumber].setEditable(false);
		setOrderInfoGrid(4, orderInfoY, 1);
		orderInfoPanel.add(tfOrderProdName[itemNumber], csOrderInfo);
		setOrderInfoGrid(5, orderInfoY, 1);
		orderInfoPanel.add(Box.createRigidArea(new Dimension(30, 0)), csOrderInfo);
		tfOrderUnitPrice[itemNumber] = new JTextField(5);
		tfOrderUnitPrice[itemNumber].setEditable(false);
		setOrderInfoGrid(6, orderInfoY, 1);
		orderInfoPanel.add(tfOrderUnitPrice[itemNumber], csOrderInfo);
		setOrderInfoGrid(7, orderInfoY, 1);
		orderInfoPanel.add(Box.createRigidArea(new Dimension(30, 0)), csOrderInfo);
		tfOrderSubTotal[itemNumber] = new JTextField(10);
		tfOrderSubTotal[itemNumber].setEditable(false);
		setOrderInfoGrid(8, orderInfoY, 1);
		orderInfoPanel.add(tfOrderSubTotal[itemNumber], csOrderInfo);
		setOrderInfoGrid(2, orderInfoY + 1, 1);
		orderInfoPanel.add(new JLabel(" "), csOrderInfo);
		orderInfoPanel.revalidate();
		// increase the Item array
		itemNumber++;
	}

	private void setAddProductGrid(int x, int y, int width) {
		csAddProduct.gridx = x;
		csAddProduct.gridy = y;
		csAddProduct.gridwidth = width;
	}

	private void setAddCustomerGrid(int x, int y, int width) {
		csAddCustomer.gridx = x;
		csAddCustomer.gridy = y;
		csAddCustomer.gridwidth = width;
	}

	private void setOrderFrameGrid(int x, int y, int width) {
		cSOrderFrame.gridx = x;
		cSOrderFrame.gridy = y;
		cSOrderFrame.gridwidth = width;
	}

	private void setOrderSummaryGrid(int x, int y, int width) {
		csOrderSummary.gridx = x;
		csOrderSummary.gridy = y;
		csOrderSummary.gridwidth = width;
	}

	private void setCustInfoGrid(int x, int y, int width) {
		csCustInfo.gridx = x;
		csCustInfo.gridy = y;
		csCustInfo.gridwidth = width;
	}

	private void setOrderInfoGrid(int x, int y, int width) {
		csOrderInfo.gridx = x;
		csOrderInfo.gridy = y;
		csOrderInfo.gridwidth = width;
	}

	private class CancelClickListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			String command = e.getActionCommand();
			if (command.equals("AddCustomerCancel")) {
				addCustFrame.dispose();
			} else if (command.equals("AddProductCancel")) {
				addProdFrame.dispose();
			} else if (command.equals("NewOrderCancel")) {
				newOrderFrame.dispose();
			}
		}
	}

	private class ResetClickListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			String command = e.getActionCommand();
			if (command.equals("AddCustomerReset")) {
				setTfCustName("");
				setTfAddress("");
				setTfPhone("");
				setTfEmail("");
			} else if (command.equals("AddProductReset")) {
				setTfProdName("");
				setTfPrice("");
			} else if (command.equals("NewOrderReset")) {
				setOrderCustomerId("");
				setTfOrderCustName("");
				setTfOrderCustAddress("");
				setTfOrderCustPhone("");
				setTfOrderCustEmail("");
				cbOrderCustNameList.setSelectedIndex(-1);
				setTfOrderID("");
				setTfOrderDate(getCurrentTime());
				setTfOrderTotal("");

				// loop - clear all "Items" variables
				for (int i = 0; i < itemNumber; i++) {
					if (cbProdNameList[i] != null && getTfOrderQantity(i).length() > 0) {
						cbProdNameList[i].setSelectedIndex(-1);
						setOrderProductId("", i);
						setTfOrderProdName("", i);
						setTfOrderUnitPrice("", i);
						setTfOrderQantity("", i);
						setTfOrderSubTotal("", i);
					}
				}
			}
		}
	}

	private class SubmitClickListener implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			String command = e.getActionCommand();
			if (command.equals("AddCustomerSubmit")) {
				if (validateAddCustomer(getTfCustName(), getTfPhone())) {
					// II insert into customer table
					DBActions.addCustomer(getTfCustName(), getTfAddress(), Long.parseLong(getTfPhone()), getTfEmail());
					statusCustLabel.setText("Added Customer " + getTfCustName() + " Successfully ");
					statusMainLabel.setText("Last Action: Added Customer " + getTfCustName() + " Successfully !");
				} else
					statusCustLabel
							.setText("Invalid Customer details provided; Please resubmit with correct information I");
			} else if (command.equals("AddProductSubmit"))

			{
				if (validateAddProduct(getTfProdName(), getTfPrice())) {
					// II insert into product table
					DBActions.addProduct(getTfProdName(), Double.parseDouble(getTfPrice()));
					statusProdLabel.setText("Added Product fn + getTfProdName()  Successfully ");
					statusMainLabel.setText("Last Action: Added Product '" + getTfProdName() + " Successfully ! ");
				} else
					statusProdLabel
							.setText("Invalid Product details provided; Please resubmit with correct information !");
			} else if (command.equals("NewOrderAddItem")) {
				addNewOrderItem();
			} else if (command.equals("NewOrderCalculate")) {
				newOrderCalculate();
			} else if (command.equals("NewOrderSubmit")) {
				newOrderCalculate();
				if (validateNewOrderSubmit(getOrderCustomerId(), getTfOrderTotal())) {
					// II insert into orders table and set OrderID
					int orderId = DBActions.addNewOrder(getOrderCustomerId(), getTfOrderTotal());
					setTfOrderID(String.valueOf(orderId));
					// II insert all items into order_detail table
					for (int i = 0; i < itemNumber; i++) {
						if (cbProdNameList[i] != null && getTfOrderQantity(i).length() > 0) {
							DBActions.addOrderDetails(orderId, Integer.parseInt(getOrderProductId(i)),
									Integer.parseInt(getTfOrderQantity(i)));
						}
					}
					statusOrderLabel.setText("New Order Placed for " + getTfOrderCustName() + "Successfully!");
					statusMainLabel
							.setText("Last Action: New Order Placed for " + getTfOrderCustName() + " Successfully!");
				} else {
					statusOrderLabel
							.setText("Invalid Order details provided; Please resubmit with valid order information !");
				}
			}
		}
	}

	private class ComboSelectListener implements ActionListener {
		@Override
		// public static final String delimiter = " : ";
		public void actionPerformed(ActionEvent e) {
			// " : "
			String command = e.getActionCommand();
			JComboBox<String> cb = (JComboBox) e.getSource();
			String msgSelected = (String) cb.getSelectedItem();
			// II System.out.println("msgSelected:"+msgSelected);
			if (msgSelected != null) {
				String[] msgParts = msgSelected.split(" : ");
				if (command.equals("CustNameList")) {
					setTfOrderCustName(msgParts[0]);
					setOrderCustomerId(msgParts[1]); // SUNIL
					if (msgParts.length > 2)
						setTfOrderCustAddress(msgParts[2]);
					if (msgParts.length > 3)
						setTfOrderCustPhone(msgParts[3]);
					if (msgParts.length > 4)
						setTfOrderCustEmail(msgParts[4]);
				}
			}
		}

	}

	private void populateProdCustList() {
		ArrayList<String> customerArrayList = new ArrayList<String>();
		ArrayList<String> productArrayList = new ArrayList<String>();
		customerArrayList = DBActions.getCustomerList();
		productArrayList = DBActions.getProductList();
		// II pull from database - on new order click
		customerList = customerArrayList.toArray(new String[customerArrayList.size()]);
		System.out.println("customerList" + customerList.length);
		// II pull from database - on new order click
		productList = productArrayList.toArray(new String[productArrayList.size()]);
	}

	private boolean validateAddCustomer(String name, String phone) {
		if (name.length() > 0) {
			try {
				// II check if any valid number passed from screen
				Long.parseLong(phone);
			} catch (Exception e) {
				// System.err.println("Invalid phone number:" + phone) i
				return false;
			}
			return true;
		} else
			return false;
	}

	private boolean validateAddProduct(String name, String price) {
		if (name.length() > 0 && price.length() > 0) {
			try {
				// check if any valid number passed from screen
				Double.parseDouble(price);
			} catch (Exception e) {
				// System.err.println("Invalid Price value:" + price);
				return false;
			}
			return true;
		} else
			return false;
	}

	private boolean validateNewOrderSubmit(String custld, String orderTotal) {
		if (custld.length() > 0 && orderTotal.length() > 0) {
			try {
				if (Double.parseDouble(orderTotal) > 0) {
					return true;

				}
			} catch (Exception e) {
				return false;
			}
		}
		return false;
	}

	private void newOrderCalculate() {
		// System.out.println("Inside calculate: " +itemNumberl;
		BigDecimal orderTotal = new BigDecimal(0.0);
		for (int i = 0; i < itemNumber; i++) {
			if (cbProdNameList[i] != null && getTfOrderQantity(i).length() > 0) {
				String prodSelected = (String) cbProdNameList[i].getSelectedItem();
				// System.out.println("Inside if condition: "+prodSelected);
				if (prodSelected != null) {
					try {
						// II check if any valid number passed from screen
						BigDecimal quantity = new BigDecimal(getTfOrderQantity(i));

						String[] msgParts = prodSelected.split(delimiter);
						setTfOrderProdName(msgParts[0], i);
						setOrderProductId(msgParts[1], i);
						setTfOrderUnitPrice(msgParts[2], i);
						BigDecimal unitPrice = new BigDecimal(getTfOrderUnitPrice(i));

						BigDecimal subTotal = unitPrice.multiply(quantity);
						setTfOrderSubTotal(String.valueOf(subTotal.setScale(2, BigDecimal.ROUND_FLOOR)), i);
						orderTotal = orderTotal.add(subTotal);
						// II System.out.println("Inside set values:
						// "+subTotal);
					} catch (Exception e) {
						statusOrderLabel
								.setText("Invalid Quantity provided; Please resubmit with valid order information !");
					}
				}
			}
		}
		if (orderTotal.equals(new BigDecimal(0.0))) {
			statusOrderLabel.setText("Order Total is zero; Please resubmit with valid orde information !");
		} else {
			setTfOrderTotal(String.valueOf(orderTotal.setScale(2, BigDecimal.ROUND_FLOOR)));
			statusOrderLabel.setText("Order not yet submitted, Please review and submit the order ! 0");
		}
	}

	private String getCurrentTime() {
		Date now = new Date();
		return now.toString();
	}

	// II getters and setters
	public String getTfCustName() {
		return tfCustName.getText().trim();
	}

	public String getTfAddress() {
		return tfAddress.getText().trim();
	}

	public String getTfProdName() {
		return tfProdName.getText().trim();
	}

	public String getTfPrice() {
		return tfPrice.getText().trim();
	}

	public void setTfCustName(String tfCustName) {
		this.tfCustName.setText(tfCustName);
	}

	public void setTfAddress(String tfAddress) {
		this.tfAddress.setText(tfAddress);
	}

	public String getTfPhone() {
		return tfPhone.getText().trim();
	}

	public void setTfPhone(String tfPhone) {
		this.tfPhone.setText(tfPhone);
	}

	public String getTfEmail() {
		return tfEmail.getText().trim();
	}

	public void setTfEmail(String tfEmail) {
		this.tfEmail.setText(tfEmail);
	}

	public void setTfProdName(String tfProdName) {
		this.tfProdName.setText(tfProdName);
	}

	public void setTfPrice(String tfPrice) {
		this.tfPrice.setText(tfPrice);
	}

	public String getTfOrderCustName() {
		return tfOrderCustName.getText().trim();
	}

	public void setTfOrderCustName(String tfOrderCustName) {
		this.tfOrderCustName.setText(tfOrderCustName);
	}

	public String getTfOrderCustAddress() {
		return tfOrderCustAddress.getText().trim();
	}

	public void setTfOrderCustAddress(String tfOrderCustAddress) {
		this.tfOrderCustAddress.setText(tfOrderCustAddress);
	}

	public String getTfOrderProdName(int pos) {
		return tfOrderProdName[pos].getText().trim();
	}

	public void setTfOrderProdName(String tfOrderProdName, int pos) {
		this.tfOrderProdName[pos].setText(tfOrderProdName);
	}

	public String getTfOrderUnitPrice(int pos) {
		return tfOrderUnitPrice[pos].getText().trim();
	}

	public void setTfOrderUnitPrice(String tfOrderUnitPrice, int pos) {
		this.tfOrderUnitPrice[pos].setText(tfOrderUnitPrice);
	}

	public String getTfOrderQantity(int pos) {
		return tfOrderQantity[pos].getText().trim();
	}

	public void setTfOrderQantity(String tfOrderQantity, int pos) {
		this.tfOrderQantity[pos].setText(tfOrderQantity);
	}

	public String getTfOrderSubTotal(int pos) {
		return tfOrderSubTotal[pos].getText().trim();
	}

	public void setTfOrderSubTotal(String tfOrderSubTotal, int pos) {
		this.tfOrderSubTotal[pos].setText(tfOrderSubTotal);
	}

	public String getTfOrderTotal() {
		return tfOrderTotal.getText().trim();
	}

	public void setTfOrderTotal(String tfOrderTotal) {
		this.tfOrderTotal.setText(tfOrderTotal);
	}

	public String getTfOrderID() {
		return tfOrderID.getText().trim();
	}

	public void setTfOrderID(String tfOrderID) {
		this.tfOrderID.setText(tfOrderID);
	}

	public String getTfOrderDate() {
		return tfOrderDate.getText().trim();
	}

	public void setTfOrderDate(String tfOrderDate) {
		this.tfOrderDate.setText(tfOrderDate);
	}

	public String getOrderCustomerId() {
		return orderCustomerld;
	}

	public void setOrderCustomerId(String customerld) {
		this.orderCustomerld = customerld;
	}

	public String getOrderProductId(int pos) {
		return orderProductld[pos];
	}

	public void setOrderProductId(String productld, int pos) {
		this.orderProductld[pos] = productld;
	}

	public String getTfOrderCustPhone() {
		return tfOrderCustPhone.getText().trim();
	}

	public void setTfOrderCustPhone(String tfOrderCustPhone) {
		this.tfOrderCustPhone.setText(tfOrderCustPhone);
	}

	public String getTfOrderCustEmail() {
		return tfOrderCustEmail.getText().trim();
	}

	public void setTfOrderCustEmail(String tfOrderCustEmail) {
		this.tfOrderCustEmail.setText(tfOrderCustEmail);
	}
}
